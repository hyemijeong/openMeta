package adapter.after;

public class Paypal {
    void payWithPayPal(int amount) {
        System.out.println("Paid " + amount + " using Paypal");
    }
}
