package adapter.after;

public class PayPalAdapter implements Payment{
    private Paypal paypal;

    public PayPalAdapter(Paypal paypal){
        this.paypal = paypal;
    }
    @Override
    public void pay(int amount) {
        paypal.payWithPayPal(amount);
    }
    
}
