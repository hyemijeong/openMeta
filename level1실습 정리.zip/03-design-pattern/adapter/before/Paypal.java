package adapter.before;

public class Paypal {
    void payWithPayPal(int amount) {
        System.out.println("Paid " + amount + " using Paypal");
    }
}
