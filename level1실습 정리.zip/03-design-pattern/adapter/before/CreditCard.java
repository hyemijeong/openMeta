package adapter.before;

public class CreditCard {
    void chargeCreditCard(int amount) {
        System.out.println("Paid " + amount + " using Credit Card");
    }
}
