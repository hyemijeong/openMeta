package facade.before;

public class Main {
    public static void main(String[] args) {
        InventorySystem is = new InventorySystem();
        PaymentSystem ps = new PaymentSystem();
        ShippingSystem ss = new ShippingSystem();

        //비즈니스 로직
        is.checkInventory(1);
        ps.processPayment(70000);
        ss.prepareShipping(1);
    }
}
