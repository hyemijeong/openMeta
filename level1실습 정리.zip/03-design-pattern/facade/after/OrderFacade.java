package facade.after;

public class OrderFacade {
    private InventorySystem inventorySystem;
    private PaymentSystem paymentSystem;
    private ShippingSystem shippingSystem;

    public OrderFacade() {
        inventorySystem = new InventorySystem();
        paymentSystem = new PaymentSystem();
        shippingSystem = new ShippingSystem();
    }

    public void processOrder(long productId, double price) {
        inventorySystem.checkInventory(productId);
        paymentSystem.processPayment(price);
        shippingSystem.prepareShipping(productId);
    }
}
