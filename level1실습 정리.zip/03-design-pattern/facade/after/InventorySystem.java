package facade.after;

public class InventorySystem {
    boolean checkInventory(long productId) {
        System.out.println("재고를 검사 합니다.");
        if(productId == 1L) {
            System.out.println("재고가 있습니다.");
            return true;
        } else {
            System.out.println("재고가 없습니다.");
            return false;
        }
    }
}
