package facade.after;

public class Main {
    public static void main(String[] args) {
        OrderFacade order = new OrderFacade();
        order.processOrder(1, 40000);
    }
}
