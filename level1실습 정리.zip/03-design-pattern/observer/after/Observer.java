package observer.after;

public interface Observer {
    void update(String productName, int newStock);
}
