package strategy.after;

public interface DiscountStrategy {
    double applyDiscount(double price);
}
