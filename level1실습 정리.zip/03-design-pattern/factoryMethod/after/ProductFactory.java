package factoryMethod.after;

public interface ProductFactory {
    Product createProduct(String name, double price);
}
