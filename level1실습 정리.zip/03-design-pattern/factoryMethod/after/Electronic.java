package factoryMethod.after;

public class Electronic extends Product{
    String modelName;
}
