package factoryMethod.after;

abstract public class Product {
    String name;
    double price;
}
