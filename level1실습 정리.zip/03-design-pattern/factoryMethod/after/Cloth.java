package factoryMethod.after;

public class Cloth extends Product{
    String size;
}
