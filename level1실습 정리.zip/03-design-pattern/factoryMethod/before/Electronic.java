package factoryMethod.before;

public class Electronic extends Product{
    String modelName;
}
