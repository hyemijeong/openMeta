package factoryMethod.before;

abstract public class Product {
    String name;
    double price;
}
