package factoryMethod.before;

public class Cloth extends Product{
    String size;
}
