# 11-web-develop-basic-Junit 실습

## Test 코드 작성
### PostControllerTest 작성과 테스트
1. 아래 내용을 참고하여 PostControllerTest 작성
> UserController
```
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.edu.board.domain.User;
import com.edu.board.dto.CreatePostRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;


@SpringBootTest
@AutoConfigureMockMvc
class PostControllerTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    protected ObjectMapper objectMapper;

    private final String ControllerURL = "/posts";

    @Test
    void postTest() throws Exception {
        //Test를 위한 사용자 생성
        User user = new User();
        user.setUserId("test1");
        user.setPassword("test");
        user.setUsername("testman");

        //MockMVC를 통한 검증
        mvc.perform(MockMvcRequestBuilders
                        .post("/users")
                        .content(objectMapper.writeValueAsString(user))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").exists())
                .andDo(print());

                
        //Test를 위한 게시글 생성
       CreatePostRequest postRequest = new CreatePostRequest();

        //사용자 정보 + 게시글 제목,내용
       postRequest.setUserId("test1");
       postRequest.setPassword("test");
       postRequest.setTitle("TEST");
       postRequest.setContent("This is Test");


        //Test를 위한 게시글 생성
        mvc.perform(MockMvcRequestBuilders
                        .post(ControllerURL)
                        .content(objectMapper.writeValueAsString(postRequest))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").exists())
                .andDo(print());
    }
}
```
2. 코드 좌측의 ▷버튼을 눌러 테스트 진행
3. 하단의 Debug console에서 내용 확인 가능
4. mvn clean install시 해당 테스트 코드가 수행된 후 jar 파일이 생성됨
