package com.edu.board.dto;

import lombok.Data;

@Data
public class CreateCommentRequest {

    private String userId;
    private String password;
    private Long postId;
    private String content;
}
