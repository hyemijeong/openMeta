package com.edu.board.controller;

import com.edu.board.domain.Post;
import com.edu.board.domain.User;
import com.edu.board.dto.CreatePostRequest;
import com.edu.board.service.PostService;
import com.edu.board.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/posts")
public class PostController {
    private final PostService postService;
    private final UserService userService;

    @Autowired
    public PostController(PostService postService, UserService userService) {
        this.postService = postService;
        this.userService = userService;
    }

    @PostMapping
    public Post create(@RequestBody CreatePostRequest request) {
        User user = userService.findById(request.getUserId());
                Post post = new Post();
                if(user != null) {
                    if(user.getPassword().equals(request.getPassword())){
                        post.setUser(user);
                    }else{
                        return null;
                    }
                }else{
                    return null;
                }
                post.setTitle(request.getTitle());
                post.setContent(request.getContent());
                return postService.save(post);
    }

    @GetMapping
    public List<Post> readAll() {
        return postService.findAll();
    }

    @GetMapping("/{id}")
    public Post readOne(@PathVariable Long id) {
        return postService.findById(id);
    }

    @PutMapping("/{id}")
    public Post update(@PathVariable Long id, @RequestBody Post newPost) {
        Post post = postService.findById(id);
        if (post != null) {
            post.setTitle(newPost.getTitle());
            post.setContent(newPost.getContent());
            return postService.save(post);
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        postService.deleteById(id);
    }
}