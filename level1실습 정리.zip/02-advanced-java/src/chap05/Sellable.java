package src.chap05;

public interface Sellable {
    double sell(int quatity);
}
