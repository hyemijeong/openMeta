package src.chap05;

public class Main {
    public static void main(String[] args) {
        Inventory<Food> lotteGangnam = new Inventory<>();
        lotteGangnam.addStock(new Food("매일우유", 1500, "2023-12-31"));
        lotteGangnam.addStock(new Food("도라에몽초코우유", 2000, "2023-10-30"));
        System.out.println(lotteGangnam.search("도라에몽초코우유").toString());
    }
}
