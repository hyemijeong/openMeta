package src.chap08;

import java.io.Serializable;

public class Product implements Serializable {
    private String name;
    public String getName() {
        return name;
    }

    private String price;
    public String getPrice() {
        return price;
    }

    public Product(String name, String price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{name='" + name + "', price=" + price + "}";
    }

    
    
    
}
