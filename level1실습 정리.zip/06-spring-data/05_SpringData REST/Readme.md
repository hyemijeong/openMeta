# 09-spring-data-스프링 데이터 REST 실습

## REST 설정
1. 설정 추가 : pom.xml에 아래 dependency 추가
> pom.xml
```
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-data-rest</artifactId>
		</dependency>
```
2. 설정 추가 : Repository에 어노테이션 추가
> UserRepository
```
@RepositoryRestResource(collectionResourceRel = "users", path = "users")
public interface UserRepository extends JpaRepository<User, String> {
}
```
3. 설정 주석 : Controller 주석
```
// @RestController
// @RequestMapping("/users")
public class UserController {
...
```
4. 빌드
```
mvn clean install

//위 명령어 수행후
java -jar target/board-0.0.1-SNAPSHOT.jar
```

## REST를 이용한 User 입력, 조회
1. Insomnia 실행
2. 아래 명령어를 통해 User 입력
```
POST http://localhost:8080/users

body: json 설정 아래 내용 작성

{
	"userId":"test1",
	"password":"test",
	"username":"testman"
}
```
3. 2번이 정상적으로 진행되면 200 OK와 함께 다음 결과 출력
```
{
	"password": "test",
	"username": "testman",
	"_links": {
		"self": {
			"href": "http://localhost:8080/users/test1"
		},
		"user": {
			"href": "http://localhost:8080/users/test1"
		}
	}
}
```
4. 아래 명령어를 이용해 User 조회
```
GET http://localhost:8080/users
```
5. 4번이 정상적으로 진행되면 200 OK와 함께 다음 결과 출력
```
{
	"_embedded": {
		"users": [
			{
				"password": "test",
				"username": "testman",
				"_links": {
					"self": {
						"href": "http://localhost:8080/users/test1"
					},
					"user": {
						"href": "http://localhost:8080/users/test1"
					}
				}
			}
		]
	},
	"_links": {
		"self": {
			"href": "http://localhost:8080/users"
		},
		"profile": {
			"href": "http://localhost:8080/profile/users"
		}
	},
	"page": {
		"size": 20,
		"totalElements": 1,
		"totalPages": 1,
		"number": 0
	}
}
```