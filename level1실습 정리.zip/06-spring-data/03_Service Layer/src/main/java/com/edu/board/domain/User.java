package com.edu.board.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "app_user")
public class User {
    @Id
    @Column(nullable = false)
    private String userId;

    @Column(nullable = false)
    private String password;
    
    @Column(nullable = false)
    private String username;

}
