# 09-spring-data-Service 레이어 실습

## Service 레이어 작성
### Repository와의 연결 (User 기준)
> UserService : Repository 선언
```
@Service
public class UserService {
    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
}
```
### Service 항목 작성 (User 기준)
> UserService : Service 항목 작성 (CRUD 기준)
```
    public User save(User user) {
        return userRepository.save(user);
    }

    public List<User> findAll() {
        return userRepository.findAll();
    }

    public User findById(String id) {
        return userRepository.findById(id).orElse(null);
    }

    public void deleteById(String id) {
        userRepository.deleteById(id);
    }
```
