# 09-spring-data-JPA Repository 실습

## 프로젝트 추가 세팅
### h2 사용을 위한 resources 설정 추가
1. src/main/resources 하위의 application.properties 선택
2. 아래 내용 추가
> application.properties
```
server.port=8080

spring.datasource.url=jdbc:h2:mem:testdb
spring.h2.console.enabled=true
```
## Repository 구성
1. Repository 작성
> UserRepository
```
package com.edu.board.repository;

import com.edu.board.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, String> {
}
```
> PostRepository
```
package com.edu.board.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    @OneToMany(mappedBy = "post")
    private List<Comment> comments;
}
```
> Comment
```
package com.edu.board.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "post_id")
    @JsonIgnore
    private Post post;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;
}
```
 
