package com.edu.board.controller;

import com.edu.board.domain.Comment;
import com.edu.board.domain.Post;
import com.edu.board.domain.User;
import com.edu.board.dto.CreateCommentRequest;
import com.edu.board.service.CommentService;
import com.edu.board.service.PostService;
import com.edu.board.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comments")
public class CommentController {
    private final CommentService commentService;
    private final PostService postService;
    private final UserService userService;

    @Autowired
    public CommentController(CommentService commentService, PostService postService, UserService userService) {
        this.commentService = commentService;
        this.postService = postService;
        this.userService = userService;
    }

    @PostMapping
    public Comment create(@RequestBody CreateCommentRequest request) {
        Post post = postService.findById(request.getPostId());
        User user = userService.findById(request.getUserId());
        Comment comment = new Comment();
        comment.setPost(post);
        comment.setUser(user);
        comment.setContent(request.getContent());
        return commentService.save(comment);
    }

    @GetMapping
    public List<Comment> readAll() {
        return commentService.findAll();
    }

    @GetMapping("/{id}")
    public Comment readOne(@PathVariable Long id) {
        return commentService.findById(id);
    }

    @PutMapping("/{id}")
    public Comment update(@PathVariable Long id, @RequestBody Comment newComment) {
        Comment comment = commentService.findById(id);
        if (comment != null) {
            comment.setContent(newComment.getContent());
            return commentService.save(comment);
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        commentService.deleteById(id);
    }
}