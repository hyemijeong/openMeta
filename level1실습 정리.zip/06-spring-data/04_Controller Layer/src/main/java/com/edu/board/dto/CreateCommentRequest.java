package com.edu.board.dto;

import lombok.Data;

@Data
public class CreateCommentRequest {
    private Long postId;
    private String userId;
    private String content;
}
