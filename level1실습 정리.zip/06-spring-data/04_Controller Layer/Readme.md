# 09-spring-data-Controller 레이어 실습

## Controller 레이어 작성
### User Controller 작성과 테스트
1. 아래 내용을 참고하여 User Controller 작성
> UserController
```
package com.edu.board.controller;

import com.edu.board.domain.User;
import com.edu.board.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }
    
    @PostMapping
    public User create(@RequestBody User user) {
        return userService.save(user);
    }

    @GetMapping
    public List<User> readAll() {
        return userService.findAll();
    }

    @GetMapping("/{id}")
    public User readOne(@PathVariable String id) {
        return userService.findById(id);
    }

    @PutMapping("/{id}")
    public User update(@PathVariable String id, @RequestBody User newUser) {
        User user = userService.findById(id);
        if (user != null) {
            user.setUsername(newUser.getUsername());
            return userService.save(user);
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        userService.deleteById(id);
    }
}
```
2. terminal에 다음 명령어를 넣어 실행
```
mvn clean install

//위 명령어 수행후
java -jar target/board-0.0.1-SNAPSHOT.jar

```
3. API Test용 Tool 설치 후 실행 (insomnia : https://insomnia.rest/)
4. Test를 위해 아래 방식으로 진행, 정상 완료시 200 OK 출력
```
POST http://localhost:8080/users

body: json 설정 아래 내용 작성

{
	"userId":"test1",
	"password":"test",
	"username":"testman"
}

```
5. Test 정상적인 수행 확인을 위해 아래 방식으로 진행, 4에서 넣은 내용이 노출된다면 완료
```
GET http://localhost:8080/users
```
### User와 동일한 방식으로 나머지 Controller 작성
