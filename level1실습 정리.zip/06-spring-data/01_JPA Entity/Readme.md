# 09-spring-data-JPA 엔티티와 연관 관계 매핑 실습

## 프로젝트 세팅
### Spring Initializr 활용
1. https://start.spring.io 접속
2. 아래 설정대로 프로젝트 설정
![image](https://github.com/dream-flow/level-1-contents/assets/17558749/ec2eb974-9621-4650-ab1a-2532af56eb13)
3. Visual Code로 실행
4. pom.xml에 아래 Dependency 추가
> pom.xml에 추가
```
		<dependency>
			<groupId>org.springdoc</groupId>
			<artifactId>springdoc-openapi-ui</artifactId>
			<version>1.5.13</version>
		</dependency>
```
5. 세팅 완료

### Domain 생성
1. 프로젝트 폴더에 Domain 폴더 생성
![image](https://github.com/dream-flow/level-1-contents/assets/17558749/d56e1450-85a5-4b66-84fc-0019949e9f84)
2. 이미지를 참고하여 각 class 생성
3. class code 세부
> user
```
package com.edu.board.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "app_user")
public class User {

    @Id
    @Column(nullable = false)
    private String userId;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String username;

}
```
> post
```
package com.edu.board.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    @OneToMany(mappedBy = "post")
    private List<Comment> comments;
}
```
> comment
```
package com.edu.board.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "post_id")
    @JsonIgnore
    private Post post;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;
}
```
