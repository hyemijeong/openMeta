package com.edu.board.controller;

import com.edu.board.domain.User;
import com.edu.board.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.media.ArraySchema;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name="사용자(/users)",  description = "사용자 관련 api 입니다.")
@RestController
@RequestMapping("/users")
public class UserController {
    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public User create(@RequestBody User user) {
        return userService.save(user);
    }

    @Operation(summary = "전체 사용자 조회", description = "사용자 목록 조회입니다")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "성공", content = {
            @Content(
              mediaType = "application/json",
              array = @ArraySchema(schema = @Schema(implementation = User.class)))
          })
    })
    @GetMapping
    public List<User> readAll() {
        return userService.findAll();
    }

    @GetMapping("/{id}")
    public User readOne(@PathVariable String id) {
        return userService.findById(id);
    }

    @PutMapping("/{id}")
    public User update(@PathVariable String id, @RequestBody User newUser) {
        User user = userService.findById(id);
        if (user != null) {
            user.setUsername(newUser.getUsername());
            return userService.save(user);
        }
        return null;
    }

    @Operation(summary = "특정 사용자 삭제", description = "해당 Id를 가진 사용자를 삭제합니다")
    @Parameters({
        @Parameter(name = "id", description = "삭제할 사용자 Id", required = true)
    })
    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        userService.deleteById(id);
    }
}