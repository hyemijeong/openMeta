package src.chap01;

public class Main {
    public static void main(String[] args) {
        Student s = new Student();
        System.out.println("Hello World");        
    }
}
