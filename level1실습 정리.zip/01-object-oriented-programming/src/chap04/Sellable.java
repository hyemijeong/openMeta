package src.chap04;

public interface Sellable {
    double sell(int quatity);
}
