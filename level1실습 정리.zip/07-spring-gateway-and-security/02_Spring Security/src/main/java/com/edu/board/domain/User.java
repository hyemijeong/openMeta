package com.edu.board.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "app_user")
public class User {
    @Id
    @Schema(description = "User's Id required for creating a user")
    @Column(nullable = false)
    private String userId;

    @Schema(description = "The user's password, required for creating a user")
    @Column(nullable = false)
    private String password;

    @Schema(description = "The user's name, required for creating a user")
    @Column(nullable = false)
    private String username;



}