# 07-spring-framework-스프링 MVC 프로젝트 세팅 및 기본 소스 실습

## 신규 프로젝트 생성(01의 프로젝트 생성과 유사)
### 1. Maven 프로젝트 생성
1) 프로젝트 폴더에 우클릭 - Create Maven Project 클릭
2) maven-archetype-quickstart 선택 후 진행
3) version : 1.4, groupId : com.example, artifactId : demo
4) 설치 진행중 version 입력 : 1.0 
5) 이후 설치 내용 요약 표시 - 엔터
### 2. pom.xml 수정
> pom.xml
```
<?xml version="1.0" encoding="EUC-KR"?>

<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>com.example</groupId>
  <artifactId>demo</artifactId>
  <version>1.0</version>
  <packaging>war</packaging>

  <name>demo</name>

  <properties>
    <org.springframework-version>5.3.19</org.springframework-version>
    <thymeleaf.version>3.0.12.RELEASE</thymeleaf.version>
  </properties>

 <dependencies>
  <!-- Spring -->
		<dependency>
			<groupId>org.springframework</groupId>
			<artifactId>spring-context</artifactId>
			<version>${org.springframework-version}</version>
		</dependency>
		<dependency>
			<groupId>org.springframework</groupId>
			<artifactId>spring-webmvc</artifactId>
			<version>${org.springframework-version}</version>      
		</dependency>
    <!--thymeleaf-->
      <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-thymeleaf</artifactId>
        <version>2.5.3</version>
    </dependency>
  <!-- JUnit -->
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.11</version>
      <scope>test</scope>
    </dependency>
  </dependencies>

  <build>
    <pluginManagement><!-- lock down plugins versions to avoid using Maven defaults (may be moved to parent pom) -->
      <plugins>
        <plugin>
          <artifactId>maven-compiler-plugin</artifactId>
          <version>3.8.0</version>
          <configuration>
              <source>1.8</source>
              <target>1.8</target>
              <encoding>UTF-8</encoding>
          </configuration>
        </plugin>
        </plugins>
    </pluginManagement>
  </build>
</project>
```
### 3.프로젝트 구조 만들기

  ![image](https://github.com/dream-flow/level-1-contents/assets/17558749/5134efcf-1e53-4b89-a6fd-df2a6057e675)

1) 위 이미지에 따라 프로젝트 구조와 파일을 생성

> Order.java
```
package com.example.model;

public class Order {
    private int id;
    private String name;
    private double price;    
}
```
> OrderService.java
```
package com.example.service;

import com.example.model.Order;

public interface OrderService {
    void placeOrder(Order order);
}
```
> OrderServiceImpl.java
```
package com.example.service;

import org.springframework.stereotype.Service;
import com.example.model.Order;

@Service
public class OrderServiceImpl implements OrderService {
    public void placeOrder(Order order) {
        // 주문 처리 로직 구현
    }
}
```
> OrderController.java
```
package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.example.model.Order;
import com.example.service.OrderService;

@Controller
public class OrderController {
    @Autowired
    private OrderService orderService;
    
    @RequestMapping(value = "/order", method = RequestMethod.GET)
    public String showOrderForm(Model model) {
        model.addAttribute("order", new Order());
        return "order";
    }
    
    @RequestMapping(value = "/order", method = RequestMethod.POST)
    public String submitOrderForm(Order order) {
        orderService.placeOrder(order);
        return "redirect:/confirmation";
    }
    
    @RequestMapping(value = "/confirmation", method = RequestMethod.GET)
    public String showConfirmationPage() {
        return "confirmation";
    }
}
```
> order.html
```
<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>주문</title>
</head>
<body>
    <h1>주문 정보 입력</h1>
    <form action="/order" method="post">
        <label for="id">ID:</label>
        <input type="text" id="id" name="id" th:field="*{id}"><br>
        <label for="name">이름:</label>
        <input type="text" id="name" name="name" th:field="*{name}"><br>
        <label for="price">금액:</label>
        <input type="text" id="price" name="price" th:field="*{price}"><br>
        <input type="submit" value="주문">
    </form>
</body>
</html>
```
> applicationContext.xml 
```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
                           http://www.springframework.org/schema/beans/spring-beans.xsd">
</beans>
```
> dispatcher-servlet.xml
```
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:mvc="http://www.springframework.org/schema/mvc"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
                           http://www.springframework.org/schema/beans/spring-beans.xsd
                           http://www.springframework.org/schema/context
                           http://www.springframework.org/schema/context/spring-context.xsd
                           http://www.springframework.org/schema/mvc
                           http://www.springframework.org/schema/mvc/spring-mvc.xsd">
    <!-- 컴포넌트 스캔을 통한 빈 등록 -->
    <context:component-scan base-package="com.example" />
    <!-- OrderService Bean 정의 -->
    <bean id="orderService" class="com.example.service.OrderServiceImpl" />
    
   <!-- DefaultServletHandlerConfigurer 활성화 -->
    <mvc:default-servlet-handler />
    
    <!-- 어노테이션 기반의 컨트롤러를 처리하기 위한 설정 -->
    <mvc:annotation-driven />

    <!-- ViewResolver 설정 -->
    <bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
        <property name="prefix" value="/WEB-INF/views/" />
        <property name="suffix" value=".html" />
    </bean>  

    <!-- Static resource mapping -->
    <mvc:resources mapping="/resources/**" location="/resources/" />
 
</beans>
```
> web.xml
```
<!-- web.xml -->

<web-app xmlns="http://java.sun.com/xml/ns/javaee" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://java.sun.com/xml/ns/javaee http://java.sun.com/xml/ns/javaee/web-app_3_0.xsd"
         version="3.0">

    <!-- Spring MVC 설정 -->
    <servlet>
        <servlet-name>dispatcher</servlet-name>
        <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
        <!-- dispatcher-servlet.xml 파일의 위치를 지정합니다. -->
        <init-param>
            <param-name>contextConfigLocation</param-name>
            <param-value>classpath:dispatcher-servlet.xml</param-value>
        </init-param>
        <load-on-startup>1</load-on-startup>
    </servlet>

    <servlet-mapping>
        <servlet-name>dispatcher</servlet-name>
        <!-- Spring MVC의 URL 매핑을 설정합니다. -->
        <url-pattern>/</url-pattern>
    </servlet-mapping>
</web-app>
```
### 4.프로젝트 구동
1. Terminal에서 mvn clean install
2. target에서 war파일을 찾아 Run on Server
3. http://localhost:8080/demo-1.0/order 접속 시에 아래 화면이 도출되면 성공
4. 별다른 기능을 붙히지 않았기에, 별도 이동은 없음
![image](https://github.com/dream-flow/level-1-contents/assets/17558749/77d0b13c-5575-4b36-bfe6-893a48431bd3)
   
