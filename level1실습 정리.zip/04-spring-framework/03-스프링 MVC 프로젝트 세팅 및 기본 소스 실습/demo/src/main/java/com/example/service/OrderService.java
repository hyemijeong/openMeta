package com.example.service;

import com.example.model.Order;

public interface OrderService {
    void placeOrder(Order order);
}
