package com.example.model;

public class Order {
    private int id;
    private String name;
    private double price;
    
}
