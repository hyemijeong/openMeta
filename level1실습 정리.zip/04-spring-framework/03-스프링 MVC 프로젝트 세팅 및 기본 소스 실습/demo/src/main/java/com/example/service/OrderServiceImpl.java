package com.example.service;

import org.springframework.stereotype.Service;
import com.example.model.Order;

@Service
public class OrderServiceImpl implements OrderService {
    public void placeOrder(Order order) {        
    }
}