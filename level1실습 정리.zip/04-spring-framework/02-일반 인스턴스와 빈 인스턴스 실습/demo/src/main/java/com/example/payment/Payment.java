package com.example.payment;

public class Payment {

    String payString = "payInfo";

    public String processPayment() {
        return "Payment... ";
    }
}
