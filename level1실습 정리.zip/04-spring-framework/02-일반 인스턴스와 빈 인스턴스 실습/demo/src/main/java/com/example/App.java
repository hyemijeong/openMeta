package com.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.config.AppConfig;
import com.example.order.Order;
import com.example.payment.Payment;

@Controller
public class App {
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {
		model.addAttribute("text", "Hello World");
		Payment payment = new Payment();
		Order order = new Order(payment);
		model.addAttribute("order", order.processOrder());

		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		Order beanOrder = context.getBean(Order.class);
		model.addAttribute("beanOrder", beanOrder.processOrder());
		((AnnotationConfigApplicationContext) context).close();

		return "home";
	}
	
}