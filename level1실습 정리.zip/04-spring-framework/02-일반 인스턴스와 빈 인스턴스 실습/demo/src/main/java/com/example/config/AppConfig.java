package com.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.order.Order;
import com.example.payment.Payment;

@Configuration
public class AppConfig {
    @Bean
    public Order order() {
        return new Order(payment());
    }

    @Bean
    public Payment payment() {
        return new Payment();
    }
}
