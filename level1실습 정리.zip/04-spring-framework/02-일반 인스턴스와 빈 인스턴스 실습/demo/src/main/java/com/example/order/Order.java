package com.example.order;

import com.example.payment.Payment;

public class Order  {
     private Payment payment;

    public Order(Payment payment) {
        this.payment = payment;
    }

    public String processOrder() {
        return payment.processPayment() + " Ordering...";
    }
}
