package com.example.model;

public class Order {
    private int id = 1;
    private String name = "test";
    private double price = 15000;
    
}
